import subprocess
import time
#dah.wav="-"
#dit.wav="."
Text = input ("messageinEN")
print("in english-", Text)
space = Text.replace(" ", " /")
fullstop = space.replace(".", " .-.-.-")
a = fullstop.replace("a", " .-")
b = a.replace("b", " -...")
c = b.replace("c", " -.-.")
d = c.replace("d", " -..")
e = d.replace("e", " .")
f = e.replace("f", " ..-.")
g = f.replace("g", " --.")
h = g.replace("h", " ....")
i = h.replace("i", " ..")
j = i.replace("j", " .---")
k = j.replace("k", " -.-")
l = k.replace("l", " .-..")
m = l.replace("m", " --")
n = m.replace("n", " -.")
o = n.replace("o", " ---")
p = o.replace("p", " .--.")
q = p.replace("q", " --.-")
r = q.replace("r", " .-.")
s = r.replace("s", " ...")
t = s.replace("t", " -")
u = t.replace("u", " ..-")
v = u.replace("v", " ...-")
w = v.replace("w", " .--")
x = w.replace("x", " -..-")
y = x.replace("y", " -.--")
z = y.replace("z", " --..")
comma = z.replace(",", " --..--")
question = comma.replace("?", " ..--..")

print(question)

for leter in question:
    if leter == "-":
        subprocess.call(["afplay","dah.wav"])
    if leter == ".":
        subprocess.call(["afplay","dit.wav"])
    else:
        time.sleep(.1)